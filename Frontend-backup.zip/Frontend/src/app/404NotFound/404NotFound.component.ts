import { Component } from '@angular/core';

@Component({
  selector: 'app-404',
  standalone: true,
  imports: [],
  templateUrl: './404NotFound.component.html',
  styleUrl: './404NotFound.component.scss'
})
export class FourZeroFourComponent {

}
