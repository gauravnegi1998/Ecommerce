export const devEnvironment = {
    production: false,
    // apiUrl: "http://localhost:8080",
    apiUrl: "https://ecommerce-backend-tan-phi.vercel.app",
}

//  --host 0.0.0.0